package sk.tuke.gamestudio;

//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class GamestudioApplicationTests {
//
//    @Test
//    void contextLoads() {
//    }
//
//}
