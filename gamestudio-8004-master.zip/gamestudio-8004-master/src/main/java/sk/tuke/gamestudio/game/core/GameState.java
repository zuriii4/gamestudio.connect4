package sk.tuke.gamestudio.game.core;
public enum GameState {
    PLAYING,
    SOLVED,
    FAILED;

}
