package sk.tuke.gamestudio.game.core;
public enum TokenState {
    EMPTY,
    MINE,
    PLAYER1,
    PLAYER2;
}
